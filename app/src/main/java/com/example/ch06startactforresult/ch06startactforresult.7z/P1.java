package com.example.ch06startactforresult;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ViewFlipper;

import androidx.fragment.app.Fragment;


/**
 * A simple {@link Fragment} subclass.
 */
public class P1 extends Fragment {
    private View mainView;
    private ViewFlipper viewFlipper;

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_p1, container, false);
    }


//    private class MyClickListener implements View.OnClickListener{
//        @Override
//        public void onClick(View v){
//            viewFlipper.showNext();
//        }
//    }
}